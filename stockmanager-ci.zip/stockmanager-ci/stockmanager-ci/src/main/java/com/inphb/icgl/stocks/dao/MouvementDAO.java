package com.inphb.icgl.stocks.dao;

import com.inphb.icgl.stocks.model.Mouvement;
import com.inphb.icgl.stocks.repository.IMouvementRepository;
import com.inphb.icgl.stocks.utils.DatabaseConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class MouvementDAO implements IMouvementRepository {

    private static final String SELECT_BASE =
        "SELECT m.*, p.designation AS nom_produit, u.nom_complet AS nom_utilisateur " +
        "FROM mouvements m " +
        "LEFT JOIN produits p ON m.id_produit = p.id " +
        "LEFT JOIN utilisateurs u ON m.id_utilisateur = u.id ";

    /**
     * Enregistre un mouvement ET met à jour la quantité en stock.
     * Les deux opérations sont dans une même transaction.
     */
    @Override
    public boolean save(Mouvement m) {
        Connection conn = null;
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);

            // 1. Vérifier le stock disponible pour une SORTIE
            if ("SORTIE".equals(m.getTypeMouvement())) {
                String checkSql = "SELECT quantite_stock FROM produits WHERE id=?";
                try (PreparedStatement check = conn.prepareStatement(checkSql)) {
                    check.setInt(1, m.getIdProduit());
                    ResultSet rs = check.executeQuery();
                    if (rs.next()) {
                        int dispo = rs.getInt("quantite_stock");
                        if (m.getQuantite() > dispo) {
                            conn.rollback();
                            System.err.println("[MouvementDAO] Stock insuffisant : " + dispo + " < " + m.getQuantite());
                            return false;
                        }
                    }
                }
            }

            // 2. Insérer le mouvement
            String sqlInsert = "INSERT INTO mouvements (id_produit, type_mouvement, quantite, motif, id_utilisateur) " +
                               "VALUES (?,?,?,?,?)";
            try (PreparedStatement ps = conn.prepareStatement(sqlInsert)) {
                ps.setInt(1, m.getIdProduit());
                ps.setString(2, m.getTypeMouvement());
                ps.setInt(3, m.getQuantite());
                ps.setString(4, m.getMotif());
                if (m.getIdUtilisateur() == 0) ps.setNull(5, Types.INTEGER);
                else ps.setInt(5, m.getIdUtilisateur());
                ps.executeUpdate();
            }

            // 3. Mettre à jour la quantité du produit
            String op = "ENTREE".equals(m.getTypeMouvement()) ? "+" : "-";
            String sqlUpdate = "UPDATE produits SET quantite_stock = quantite_stock " + op + " ? WHERE id=?";
            try (PreparedStatement ps = conn.prepareStatement(sqlUpdate)) {
                ps.setInt(1, m.getQuantite());
                ps.setInt(2, m.getIdProduit());
                ps.executeUpdate();
            }

            conn.commit();
            return true;

        } catch (SQLException e) {
            System.err.println("[MouvementDAO.save] " + e.getMessage());
            try { if (conn != null) conn.rollback(); } catch (SQLException ex) { /* ignoré */ }
            return false;
        } finally {
            try { if (conn != null) conn.setAutoCommit(true); } catch (SQLException ex) { /* ignoré */ }
        }
    }

    @Override
    public Mouvement findById(int id) {
        String sql = SELECT_BASE + "WHERE m.id=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
        } catch (SQLException e) {
            System.err.println("[MouvementDAO.findById] " + e.getMessage());
        }
        return null;
    }

    @Override
    public ObservableList<Mouvement> findAll(int page, int pageSize) {
        ObservableList<Mouvement> list = FXCollections.observableArrayList();
        String sql = SELECT_BASE + "ORDER BY m.date_mouvement DESC LIMIT ? OFFSET ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, pageSize);
            ps.setInt(2, (page - 1) * pageSize);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            System.err.println("[MouvementDAO.findAll] " + e.getMessage());
        }
        return list;
    }

    @Override
    public int countAll() {
        String sql = "SELECT COUNT(*) FROM mouvements";
        try (Statement st = DatabaseConnection.getConnection().createStatement()) {
            ResultSet rs = st.executeQuery(sql);
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("[MouvementDAO.countAll] " + e.getMessage());
        }
        return 0;
    }

    @Override
    public ObservableList<Mouvement> findByProduit(int idProduit, int page, int pageSize) {
        ObservableList<Mouvement> list = FXCollections.observableArrayList();
        String sql = SELECT_BASE + "WHERE m.id_produit=? ORDER BY m.date_mouvement DESC LIMIT ? OFFSET ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, idProduit);
            ps.setInt(2, pageSize);
            ps.setInt(3, (page - 1) * pageSize);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            System.err.println("[MouvementDAO.findByProduit] " + e.getMessage());
        }
        return list;
    }

    @Override
    public ObservableList<Mouvement> findByDate(LocalDate date, int page, int pageSize) {
        ObservableList<Mouvement> list = FXCollections.observableArrayList();
        String sql = SELECT_BASE + "WHERE DATE(m.date_mouvement)=? ORDER BY m.date_mouvement DESC LIMIT ? OFFSET ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(date));
            ps.setInt(2, pageSize);
            ps.setInt(3, (page - 1) * pageSize);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            System.err.println("[MouvementDAO.findByDate] " + e.getMessage());
        }
        return list;
    }

    @Override
    public int countMouvementsDuJour() {
        String sql = "SELECT COUNT(*) FROM mouvements WHERE DATE(date_mouvement) = CURDATE()";
        try (Statement st = DatabaseConnection.getConnection().createStatement()) {
            ResultSet rs = st.executeQuery(sql);
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("[MouvementDAO.countMouvementsDuJour] " + e.getMessage());
        }
        return 0;
    }

    private Mouvement map(ResultSet rs) throws SQLException {
        Timestamp ts = rs.getTimestamp("date_mouvement");
        LocalDateTime ldt = ts != null ? ts.toLocalDateTime() : null;
        return new Mouvement(
            rs.getInt("id"),
            rs.getInt("id_produit"),
            rs.getString("nom_produit"),
            rs.getString("type_mouvement"),
            rs.getInt("quantite"),
            rs.getString("motif"),
            rs.getInt("id_utilisateur"),
            rs.getString("nom_utilisateur"),
            ldt
        );
    }
}
