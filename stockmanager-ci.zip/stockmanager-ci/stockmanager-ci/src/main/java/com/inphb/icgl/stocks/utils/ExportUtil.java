package com.inphb.icgl.stocks.utils;

import com.inphb.icgl.stocks.model.Produit;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

/**
 * Utilitaire d'export Excel (XLSX) via Apache POI.
 * Les cellules des produits en alerte sont colorées en rouge.
 */
public class ExportUtil {

    private ExportUtil() {}

    /**
     * Exporte la liste de produits dans un fichier Excel .xlsx.
     *
     * @param produits Liste des produits à exporter
     * @param fichier  Fichier de destination (chemin choisi par l'utilisateur via FileChooser)
     * @throws IOException si l'écriture échoue
     */
    public static void exporterProduits(List<Produit> produits, File fichier) throws IOException {
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            XSSFSheet sheet = workbook.createSheet("Produits StockManager CI");

            // ── Style en-tête : fond bleu foncé, texte blanc gras ─────────────
            XSSFCellStyle styleEntete = workbook.createCellStyle();
            styleEntete.setFillForegroundColor(
                new XSSFColor(new byte[]{(byte) 27, (byte) 58, (byte) 107}, null));
            styleEntete.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            styleEntete.setAlignment(HorizontalAlignment.CENTER);
            styleEntete.setBorderBottom(BorderStyle.THIN);
            XSSFFont fontBlanc = workbook.createFont();
            fontBlanc.setColor(IndexedColors.WHITE.getIndex());
            fontBlanc.setBold(true);
            fontBlanc.setFontHeightInPoints((short) 11);
            styleEntete.setFont(fontBlanc);

            // ── Style alerte : fond rouge clair ───────────────────────────────
            XSSFCellStyle styleAlerte = workbook.createCellStyle();
            styleAlerte.setFillForegroundColor(
                new XSSFColor(new byte[]{(byte) 255, (byte) 200, (byte) 200}, null));
            styleAlerte.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // ── Style normal ──────────────────────────────────────────────────
            XSSFCellStyle styleNormal = workbook.createCellStyle();
            styleNormal.setFillForegroundColor(
                new XSSFColor(new byte[]{(byte) 255, (byte) 255, (byte) 255}, null));
            styleNormal.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // ── Ligne d'en-tête ───────────────────────────────────────────────
            String[] entetes = {
                "Référence", "Désignation", "Catégorie", "Fournisseur",
                "Prix (FCFA)", "Quantité", "Stock Min", "Unité", "⚠ Alerte"
            };
            Row ligneEntete = sheet.createRow(0);
            ligneEntete.setHeightInPoints(18);
            for (int i = 0; i < entetes.length; i++) {
                Cell cell = ligneEntete.createCell(i);
                cell.setCellValue(entetes[i]);
                cell.setCellStyle(styleEntete);
                sheet.setColumnWidth(i, 5000);
            }

            // ── Lignes de données ─────────────────────────────────────────────
            int numLigne = 1;
            for (Produit p : produits) {
                Row row = sheet.createRow(numLigne++);
                boolean enAlerte = p.isEnAlerte();
                XSSFCellStyle style = enAlerte ? styleAlerte : styleNormal;

                String[] valeurs = {
                    p.getReference(),
                    p.getDesignation(),
                    p.getNomCategorie() != null ? p.getNomCategorie() : "-",
                    p.getNomFournisseur() != null ? p.getNomFournisseur() : "-",
                    String.format("%.0f", p.getPrixUnitaire()),
                    String.valueOf(p.getQuantiteStock()),
                    String.valueOf(p.getStockMinimum()),
                    p.getUnite(),
                    enAlerte ? "⚠ OUI" : "NON"
                };

                for (int i = 0; i < valeurs.length; i++) {
                    Cell cell = row.createCell(i);
                    cell.setCellValue(valeurs[i]);
                    cell.setCellStyle(style);
                }
            }

            // ── Sauvegarder le fichier ────────────────────────────────────────
            try (FileOutputStream fos = new FileOutputStream(fichier)) {
                workbook.write(fos);
            }
        }
    }
}
