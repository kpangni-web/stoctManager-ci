package com.inphb.icgl.stocks.model;

import javafx.beans.property.*;
import java.time.LocalDateTime;

public class Mouvement {
    private final IntegerProperty id = new SimpleIntegerProperty();
    private final IntegerProperty idProduit = new SimpleIntegerProperty();
    private final StringProperty nomProduit = new SimpleStringProperty();
    private final StringProperty typeMouvement = new SimpleStringProperty(); // ENTREE / SORTIE
    private final IntegerProperty quantite = new SimpleIntegerProperty();
    private final StringProperty motif = new SimpleStringProperty();
    private final IntegerProperty idUtilisateur = new SimpleIntegerProperty();
    private final StringProperty nomUtilisateur = new SimpleStringProperty();
    private LocalDateTime dateMouvement;

    public Mouvement() {}

    public Mouvement(int id, int idProduit, String nomProduit,
                     String typeMouvement, int quantite, String motif,
                     int idUtilisateur, String nomUtilisateur, LocalDateTime dateMouvement) {
        this.id.set(id);
        this.idProduit.set(idProduit);
        this.nomProduit.set(nomProduit);
        this.typeMouvement.set(typeMouvement);
        this.quantite.set(quantite);
        this.motif.set(motif);
        this.idUtilisateur.set(idUtilisateur);
        this.nomUtilisateur.set(nomUtilisateur);
        this.dateMouvement = dateMouvement;
    }

    public int getId() { return id.get(); }
    public void setId(int v) { id.set(v); }
    public IntegerProperty idProperty() { return id; }

    public int getIdProduit() { return idProduit.get(); }
    public void setIdProduit(int v) { idProduit.set(v); }
    public IntegerProperty idProduitProperty() { return idProduit; }

    public String getNomProduit() { return nomProduit.get(); }
    public void setNomProduit(String v) { nomProduit.set(v); }
    public StringProperty nomProduitProperty() { return nomProduit; }

    public String getTypeMouvement() { return typeMouvement.get(); }
    public void setTypeMouvement(String v) { typeMouvement.set(v); }
    public StringProperty typeMouvementProperty() { return typeMouvement; }

    public int getQuantite() { return quantite.get(); }
    public void setQuantite(int v) { quantite.set(v); }
    public IntegerProperty quantiteProperty() { return quantite; }

    public String getMotif() { return motif.get(); }
    public void setMotif(String v) { motif.set(v); }
    public StringProperty motifProperty() { return motif; }

    public int getIdUtilisateur() { return idUtilisateur.get(); }
    public void setIdUtilisateur(int v) { idUtilisateur.set(v); }
    public IntegerProperty idUtilisateurProperty() { return idUtilisateur; }

    public String getNomUtilisateur() { return nomUtilisateur.get(); }
    public void setNomUtilisateur(String v) { nomUtilisateur.set(v); }
    public StringProperty nomUtilisateurProperty() { return nomUtilisateur; }

    public LocalDateTime getDateMouvement() { return dateMouvement; }
    public void setDateMouvement(LocalDateTime v) { dateMouvement = v; }

    /** Retourne la date formatée pour l'affichage dans le TableView */
    public String getDateFormatee() {
        if (dateMouvement == null) return "";
        return String.format("%02d/%02d/%04d %02d:%02d",
            dateMouvement.getDayOfMonth(), dateMouvement.getMonthValue(),
            dateMouvement.getYear(), dateMouvement.getHour(), dateMouvement.getMinute());
    }
}
