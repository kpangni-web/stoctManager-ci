package com.inphb.icgl.stocks.controller;

import com.inphb.icgl.stocks.utils.SessionManager;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class MainLayoutController {

    @FXML private StackPane contentArea;
    @FXML private Button    btnUtilisateurs;

    @FXML
    public void initialize() {
        // Cacher le menu Utilisateurs si non admin
        btnUtilisateurs.setVisible(SessionManager.isAdmin());
        btnUtilisateurs.setManaged(SessionManager.isAdmin());

        // Charger le tableau de bord par défaut
        showDashboard();
    }

    @FXML public void showDashboard()    { chargerVue("/fxml/Dashboard.fxml"); }
    @FXML public void showCategories()   { chargerVue("/fxml/Categorie.fxml"); }
    @FXML public void showFournisseurs() { chargerVue("/fxml/Fournisseur.fxml"); }
    @FXML public void showProduits()     { chargerVue("/fxml/Produit.fxml"); }
    @FXML public void showMouvements()   { chargerVue("/fxml/Mouvement.fxml"); }
    @FXML public void showUtilisateurs() {
        if (SessionManager.isAdmin()) chargerVue("/fxml/Utilisateur.fxml");
    }

    @FXML
    private void handleDeconnexion() {
        SessionManager.logout();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/Login.fxml"));
            Stage loginStage = new Stage();
            loginStage.setTitle("StockManager CI — Connexion");
            loginStage.setScene(new Scene(loader.load(), 420, 320));
            loginStage.setResizable(false);
            loginStage.show();
            // Fermer la fenêtre principale
            Stage mainStage = (Stage) contentArea.getScene().getWindow();
            mainStage.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void chargerVue(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Node vue = loader.load();
            contentArea.getChildren().setAll(vue);
        } catch (Exception e) {
            System.err.println("[MainLayout] Erreur chargement vue " + fxmlPath + " : " + e.getMessage());
            e.printStackTrace();
        }
    }
}
