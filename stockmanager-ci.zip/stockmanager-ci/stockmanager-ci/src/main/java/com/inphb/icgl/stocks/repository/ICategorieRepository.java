package com.inphb.icgl.stocks.repository;

import com.inphb.icgl.stocks.model.Categorie;
import javafx.collections.ObservableList;

public interface ICategorieRepository {
    boolean save(Categorie c);
    boolean update(Categorie c);
    boolean delete(int id);
    Categorie findById(int id);
    ObservableList<Categorie> findAll(int page, int pageSize);
    ObservableList<Categorie> findAll(); // sans pagination (pour ComboBox)
    int countAll();
    ObservableList<Categorie> search(String motCle, int page, int pageSize);
    int countSearch(String motCle);
    boolean hasProducts(int idCategorie); // vérifie si des produits sont liés
}
