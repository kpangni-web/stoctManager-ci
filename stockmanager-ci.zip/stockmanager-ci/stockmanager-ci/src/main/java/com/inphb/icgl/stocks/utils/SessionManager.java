package com.inphb.icgl.stocks.utils;

import com.inphb.icgl.stocks.model.Utilisateur;

/**
 * Singleton statique qui stocke l'utilisateur connecté.
 * Accessible depuis n'importe quel contrôleur sans paramètre.
 */
public class SessionManager {

    private static Utilisateur utilisateurConnecte = null;

    private SessionManager() {}

    public static void setUtilisateur(Utilisateur u) {
        utilisateurConnecte = u;
    }

    public static Utilisateur getUtilisateur() {
        return utilisateurConnecte;
    }

    public static boolean isAdmin() {
        return utilisateurConnecte != null &&
               "ADMIN".equals(utilisateurConnecte.getRole());
    }

    public static boolean isConnecte() {
        return utilisateurConnecte != null;
    }

    public static void logout() {
        utilisateurConnecte = null;
    }
}
