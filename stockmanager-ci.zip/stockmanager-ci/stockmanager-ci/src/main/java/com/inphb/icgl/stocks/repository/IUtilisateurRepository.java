package com.inphb.icgl.stocks.repository;

import com.inphb.icgl.stocks.model.Utilisateur;
import javafx.collections.ObservableList;

public interface IUtilisateurRepository {
    boolean save(Utilisateur u);
    boolean update(Utilisateur u);
    boolean desactiver(int id);  // désactiver (pas de suppression physique)
    Utilisateur findById(int id);
    Utilisateur findByLogin(String login);
    Utilisateur authenticate(String login, String motDePasseHash); // connexion
    ObservableList<Utilisateur> findAll(int page, int pageSize);
    int countAll();
}
