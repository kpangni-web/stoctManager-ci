package com.inphb.icgl.stocks.dao;

import com.inphb.icgl.stocks.model.Utilisateur;
import com.inphb.icgl.stocks.repository.IUtilisateurRepository;
import com.inphb.icgl.stocks.utils.DatabaseConnection;
import com.inphb.icgl.stocks.utils.PasswordUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;

public class UtilisateurDAO implements IUtilisateurRepository {

    @Override
    public boolean save(Utilisateur u) {
        String sql = "INSERT INTO utilisateurs (nom_complet, login, mot_de_passe, role, actif) VALUES (?,?,?,?,?)";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, u.getNomComplet());
            ps.setString(2, u.getLogin());
            ps.setString(3, PasswordUtil.sha256(u.getMotDePasse())); // hashage avant stockage
            ps.setString(4, u.getRole());
            ps.setBoolean(5, u.isActif());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[UtilisateurDAO.save] " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean update(Utilisateur u) {
        // Si le mot de passe est vide, on ne le modifie pas
        String sql;
        if (u.getMotDePasse() == null || u.getMotDePasse().isEmpty()) {
            sql = "UPDATE utilisateurs SET nom_complet=?, login=?, role=?, actif=? WHERE id=?";
            try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
                ps.setString(1, u.getNomComplet());
                ps.setString(2, u.getLogin());
                ps.setString(3, u.getRole());
                ps.setBoolean(4, u.isActif());
                ps.setInt(5, u.getId());
                return ps.executeUpdate() > 0;
            } catch (SQLException e) {
                System.err.println("[UtilisateurDAO.update] " + e.getMessage());
                return false;
            }
        } else {
            sql = "UPDATE utilisateurs SET nom_complet=?, login=?, mot_de_passe=?, role=?, actif=? WHERE id=?";
            try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
                ps.setString(1, u.getNomComplet());
                ps.setString(2, u.getLogin());
                ps.setString(3, PasswordUtil.sha256(u.getMotDePasse()));
                ps.setString(4, u.getRole());
                ps.setBoolean(5, u.isActif());
                ps.setInt(6, u.getId());
                return ps.executeUpdate() > 0;
            } catch (SQLException e) {
                System.err.println("[UtilisateurDAO.update+mdp] " + e.getMessage());
                return false;
            }
        }
    }

    @Override
    public boolean desactiver(int id) {
        String sql = "UPDATE utilisateurs SET actif=0 WHERE id=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[UtilisateurDAO.desactiver] " + e.getMessage());
            return false;
        }
    }

    @Override
    public Utilisateur findById(int id) {
        String sql = "SELECT * FROM utilisateurs WHERE id=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
        } catch (SQLException e) {
            System.err.println("[UtilisateurDAO.findById] " + e.getMessage());
        }
        return null;
    }

    @Override
    public Utilisateur findByLogin(String login) {
        String sql = "SELECT * FROM utilisateurs WHERE login=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, login);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
        } catch (SQLException e) {
            System.err.println("[UtilisateurDAO.findByLogin] " + e.getMessage());
        }
        return null;
    }

    /**
     * Authentifie un utilisateur : compare le hash SHA-256 du mot de passe saisi
     * avec le hash stocké en base. Vérifie aussi que le compte est actif.
     */
    @Override
    public Utilisateur authenticate(String login, String motDePasseHash) {
        String sql = "SELECT * FROM utilisateurs WHERE login=? AND mot_de_passe=? AND actif=1";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, login);
            ps.setString(2, motDePasseHash);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
        } catch (SQLException e) {
            System.err.println("[UtilisateurDAO.authenticate] " + e.getMessage());
        }
        return null;
    }

    @Override
    public ObservableList<Utilisateur> findAll(int page, int pageSize) {
        ObservableList<Utilisateur> list = FXCollections.observableArrayList();
        String sql = "SELECT * FROM utilisateurs ORDER BY nom_complet LIMIT ? OFFSET ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, pageSize);
            ps.setInt(2, (page - 1) * pageSize);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            System.err.println("[UtilisateurDAO.findAll] " + e.getMessage());
        }
        return list;
    }

    @Override
    public int countAll() {
        String sql = "SELECT COUNT(*) FROM utilisateurs";
        try (Statement st = DatabaseConnection.getConnection().createStatement()) {
            ResultSet rs = st.executeQuery(sql);
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("[UtilisateurDAO.countAll] " + e.getMessage());
        }
        return 0;
    }

    private Utilisateur map(ResultSet rs) throws SQLException {
        Utilisateur u = new Utilisateur(
            rs.getInt("id"),
            rs.getString("nom_complet"),
            rs.getString("login"),
            rs.getString("role"),
            rs.getBoolean("actif")
        );
        // Le hash est chargé pour les besoins internes (jamais affiché)
        u.setMotDePasse(rs.getString("mot_de_passe"));
        return u;
    }
}
