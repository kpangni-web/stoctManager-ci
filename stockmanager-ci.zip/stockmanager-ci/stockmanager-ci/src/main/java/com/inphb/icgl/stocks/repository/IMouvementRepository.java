package com.inphb.icgl.stocks.repository;

import com.inphb.icgl.stocks.model.Mouvement;
import javafx.collections.ObservableList;
import java.time.LocalDate;

public interface IMouvementRepository {
    boolean save(Mouvement m);  // INSERT + mise à jour quantite_stock
    Mouvement findById(int id);
    ObservableList<Mouvement> findAll(int page, int pageSize);
    int countAll();
    ObservableList<Mouvement> findByProduit(int idProduit, int page, int pageSize);
    ObservableList<Mouvement> findByDate(LocalDate date, int page, int pageSize);
    int countMouvementsDuJour();
    // Pas de update/delete : traçabilité immuable
}
