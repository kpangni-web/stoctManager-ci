package com.inphb.icgl.stocks.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Singleton gérant la connexion JDBC à MySQL.
 * Une seule connexion est ouverte pour toute l'application.
 */
public class DatabaseConnection {

    // ── Paramètres de connexion ────────────────────────────────────────────────
    private static final String URL      = "jdbc:mysql://localhost:3306/stockmanager_ci" +
                                           "?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String USER     = "root";
    private static final String PASSWORD = "armel2007";  // ← À adapter selon votre config MySQL

    private static Connection connection = null;

    /** Empêche l'instanciation directe */
    private DatabaseConnection() {}

    /**
     * Retourne la connexion unique, en la créant si nécessaire.
     */
    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
        }
        return connection;
    }

    /**
     * Teste si la connexion peut s'établir.
     * @return true si OK, false en cas d'erreur.
     */
    public static boolean testConnection() {
        try {
            Connection c = DriverManager.getConnection(URL, USER, PASSWORD);
            c.close();
            return true;
        } catch (SQLException e) {
            System.err.println("[DB] Connexion échouée : " + e.getMessage());
            return false;
        }
    }

    /** Ferme proprement la connexion à l'arrêt de l'application. */
    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("[DB] Connexion fermée.");
            } catch (SQLException e) {
                System.err.println("[DB] Erreur à la fermeture : " + e.getMessage());
            }
        }
    }
}
