package com.inphb.icgl.stocks;

import com.inphb.icgl.stocks.utils.DatabaseConnection;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        // 1. Vérifier la connexion à la base de données au démarrage
        if (!DatabaseConnection.testConnection()) {
            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(
                javafx.scene.control.Alert.AlertType.ERROR);
            alert.setTitle("Erreur de connexion");
            alert.setHeaderText("Impossible de se connecter à la base de données");
            alert.setContentText("Vérifiez que MySQL est démarré et que la base 'stockmanager_ci' existe.\n" +
                                 "Hôte : localhost:3306\nBase : stockmanager_ci");
            alert.showAndWait();
            System.exit(1);
        }

        // 2. Préparer la fenêtre de connexion (Login)
        FXMLLoader loginLoader = new FXMLLoader(getClass().getResource("/fxml/Login.fxml"));
        Stage loginStage = new Stage();
        loginStage.setTitle("StockManager CI — Connexion");
        loginStage.setScene(new Scene(loginLoader.load(), 420, 320));
        loginStage.setResizable(false);

        // 3. Afficher le Splash Screen puis la fenêtre Login
        SplashScreen splash = new SplashScreen();
        splash.showAndProceed(loginStage);
    }

    @Override
    public void stop() throws Exception {
        DatabaseConnection.closeConnection();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

//pour executer
//   mvn clean javafx:run