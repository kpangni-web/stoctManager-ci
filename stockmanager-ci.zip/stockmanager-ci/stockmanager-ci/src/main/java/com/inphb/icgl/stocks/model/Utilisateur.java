package com.inphb.icgl.stocks.model;

import javafx.beans.property.*;

public class Utilisateur {
    private final IntegerProperty id = new SimpleIntegerProperty();
    private final StringProperty nomComplet = new SimpleStringProperty();
    private final StringProperty login = new SimpleStringProperty();
    private final StringProperty motDePasse = new SimpleStringProperty();
    private final StringProperty role = new SimpleStringProperty();
    private final BooleanProperty actif = new SimpleBooleanProperty();

    public Utilisateur() {}

    public Utilisateur(int id, String nomComplet, String login, String role, boolean actif) {
        this.id.set(id);
        this.nomComplet.set(nomComplet);
        this.login.set(login);
        this.role.set(role);
        this.actif.set(actif);
    }

    // --- id ---
    public int getId() { return id.get(); }
    public void setId(int v) { id.set(v); }
    public IntegerProperty idProperty() { return id; }

    // --- nomComplet ---
    public String getNomComplet() { return nomComplet.get(); }
    public void setNomComplet(String v) { nomComplet.set(v); }
    public StringProperty nomCompletProperty() { return nomComplet; }

    // --- login ---
    public String getLogin() { return login.get(); }
    public void setLogin(String v) { login.set(v); }
    public StringProperty loginProperty() { return login; }

    // --- motDePasse ---
    public String getMotDePasse() { return motDePasse.get(); }
    public void setMotDePasse(String v) { motDePasse.set(v); }
    public StringProperty motDePasseProperty() { return motDePasse; }

    // --- role ---
    public String getRole() { return role.get(); }
    public void setRole(String v) { role.set(v); }
    public StringProperty roleProperty() { return role; }

    // --- actif ---
    public boolean isActif() { return actif.get(); }
    public void setActif(boolean v) { actif.set(v); }
    public BooleanProperty actifProperty() { return actif; }

    @Override
    public String toString() { return nomComplet.get() + " (" + login.get() + ")"; }
}
