package com.inphb.icgl.stocks.dao;

import com.inphb.icgl.stocks.model.Categorie;
import com.inphb.icgl.stocks.repository.ICategorieRepository;
import com.inphb.icgl.stocks.utils.DatabaseConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;

public class CategorieDAO implements ICategorieRepository {

    @Override
    public boolean save(Categorie c) {
        String sql = "INSERT INTO categories (libelle, description) VALUES (?, ?)";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, c.getLibelle());
            ps.setString(2, c.getDescription());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[CategorieDAO.save] " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean update(Categorie c) {
        String sql = "UPDATE categories SET libelle=?, description=? WHERE id=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, c.getLibelle());
            ps.setString(2, c.getDescription());
            ps.setInt(3, c.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[CategorieDAO.update] " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM categories WHERE id=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[CategorieDAO.delete] " + e.getMessage());
            return false;
        }
    }

    @Override
    public Categorie findById(int id) {
        String sql = "SELECT * FROM categories WHERE id=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
        } catch (SQLException e) {
            System.err.println("[CategorieDAO.findById] " + e.getMessage());
        }
        return null;
    }

    @Override
    public ObservableList<Categorie> findAll(int page, int pageSize) {
        ObservableList<Categorie> list = FXCollections.observableArrayList();
        String sql = "SELECT * FROM categories ORDER BY libelle LIMIT ? OFFSET ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, pageSize);
            ps.setInt(2, (page - 1) * pageSize);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            System.err.println("[CategorieDAO.findAll] " + e.getMessage());
        }
        return list;
    }

    @Override
    public ObservableList<Categorie> findAll() {
        ObservableList<Categorie> list = FXCollections.observableArrayList();
        String sql = "SELECT * FROM categories ORDER BY libelle";
        try (Statement st = DatabaseConnection.getConnection().createStatement()) {
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            System.err.println("[CategorieDAO.findAll()] " + e.getMessage());
        }
        return list;
    }

    @Override
    public int countAll() {
        String sql = "SELECT COUNT(*) FROM categories";
        try (Statement st = DatabaseConnection.getConnection().createStatement()) {
            ResultSet rs = st.executeQuery(sql);
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("[CategorieDAO.countAll] " + e.getMessage());
        }
        return 0;
    }

    @Override
    public ObservableList<Categorie> search(String motCle, int page, int pageSize) {
        ObservableList<Categorie> list = FXCollections.observableArrayList();
        String sql = "SELECT * FROM categories WHERE libelle LIKE ? ORDER BY libelle LIMIT ? OFFSET ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, "%" + motCle + "%");
            ps.setInt(2, pageSize);
            ps.setInt(3, (page - 1) * pageSize);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            System.err.println("[CategorieDAO.search] " + e.getMessage());
        }
        return list;
    }

    @Override
    public int countSearch(String motCle) {
        String sql = "SELECT COUNT(*) FROM categories WHERE libelle LIKE ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, "%" + motCle + "%");
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("[CategorieDAO.countSearch] " + e.getMessage());
        }
        return 0;
    }

    @Override
    public boolean hasProducts(int idCategorie) {
        String sql = "SELECT COUNT(*) FROM produits WHERE id_categorie=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, idCategorie);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1) > 0;
        } catch (SQLException e) {
            System.err.println("[CategorieDAO.hasProducts] " + e.getMessage());
        }
        return false;
    }

    private Categorie map(ResultSet rs) throws SQLException {
        return new Categorie(
            rs.getInt("id"),
            rs.getString("libelle"),
            rs.getString("description")
        );
    }
}
