package com.inphb.icgl.stocks.controller;

import com.inphb.icgl.stocks.dao.FournisseurDAO;
import com.inphb.icgl.stocks.model.Fournisseur;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class FournisseurController {

    @FXML private TableView<Fournisseur>            tableFournisseurs;
    @FXML private TableColumn<Fournisseur, Integer> colId;
    @FXML private TableColumn<Fournisseur, String>  colNom;
    @FXML private TableColumn<Fournisseur, String>  colTel;
    @FXML private TableColumn<Fournisseur, String>  colEmail;
    @FXML private TableColumn<Fournisseur, String>  colVille;

    @FXML private TextField txtNom;
    @FXML private TextField txtTelephone;
    @FXML private TextField txtEmail;
    @FXML private TextField txtAdresse;
    @FXML private TextField txtVille;
    @FXML private Button    btnAjouter;
    @FXML private Button    btnModifier;
    @FXML private Button    btnSupprimer;
    @FXML private Button    btnAnnuler;
    @FXML private TextField txtRecherche;
    @FXML private Label     lblPagination;
    @FXML private Button    btnPrecedent;
    @FXML private Button    btnSuivant;

    private final FournisseurDAO dao = new FournisseurDAO();
    private static final int PAGE_SIZE = 15;
    private int pageCourante = 1, totalPages = 1;
    private String motCle = "";
    private Fournisseur selection = null;

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        colTel.setCellValueFactory(new PropertyValueFactory<>("telephone"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colVille.setCellValueFactory(new PropertyValueFactory<>("ville"));

        tableFournisseurs.getSelectionModel().selectedItemProperty()
            .addListener((obs, old, f) -> {
                if (f != null) {
                    selection = f;
                    txtNom.setText(f.getNom());
                    txtTelephone.setText(f.getTelephone());
                    txtEmail.setText(f.getEmail());
                    txtAdresse.setText(f.getAdresse());
                    txtVille.setText(f.getVille());
                    btnModifier.setDisable(false);
                    btnSupprimer.setDisable(false);
                    btnAjouter.setDisable(true);
                }
            });

        txtRecherche.textProperty().addListener((obs, old, val) -> {
            motCle = val.trim(); pageCourante = 1; chargerPage();
        });
        chargerPage(); modeAjout();
    }

    private void chargerPage() {
        int total; ObservableList<Fournisseur> data;
        if (motCle.isEmpty()) { total = dao.countAll(); data = dao.findAll(pageCourante, PAGE_SIZE); }
        else { total = dao.countSearch(motCle); data = dao.search(motCle, pageCourante, PAGE_SIZE); }
        totalPages = Math.max(1, (int) Math.ceil((double) total / PAGE_SIZE));
        tableFournisseurs.setItems(data);
        lblPagination.setText("Page " + pageCourante + " / " + totalPages + " — " + total + " fournisseur(s)");
        btnPrecedent.setDisable(pageCourante <= 1);
        btnSuivant.setDisable(pageCourante >= totalPages);
    }

    @FXML private void handlePrecedent() { pageCourante--; chargerPage(); }
    @FXML private void handleSuivant()   { pageCourante++; chargerPage(); }

    @FXML
    private void handleAjouter() {
        if (txtNom.getText().trim().isEmpty()) { alerte("Le nom est obligatoire."); return; }
        Fournisseur f = buildFournisseur(new Fournisseur());
        if (dao.save(f)) { succes("Fournisseur ajouté."); modeAjout(); chargerPage(); }
        else alerte("Ajout échoué.");
    }

    @FXML
    private void handleModifier() {
        if (selection == null) return;
        buildFournisseur(selection);
        if (dao.update(selection)) { succes("Fournisseur modifié."); modeAjout(); chargerPage(); }
        else alerte("Modification échouée.");
    }

    @FXML
    private void handleSupprimer() {
        if (selection == null) return;
        if (dao.hasProducts(selection.getId())) {
            alerte("Des produits sont rattachés à ce fournisseur. Réaffectez-les d'abord.");
            return;
        }
        Alert c = new Alert(Alert.AlertType.CONFIRMATION, "Supprimer " + selection.getNom() + " ?",
            ButtonType.YES, ButtonType.NO);
        c.showAndWait().ifPresent(b -> {
            if (b == ButtonType.YES && dao.delete(selection.getId())) {
                succes("Fournisseur supprimé."); modeAjout(); chargerPage();
            }
        });
    }

    @FXML private void handleAnnuler() { modeAjout(); }

    private Fournisseur buildFournisseur(Fournisseur f) {
        f.setNom(txtNom.getText().trim());
        f.setTelephone(txtTelephone.getText().trim());
        f.setEmail(txtEmail.getText().trim());
        f.setAdresse(txtAdresse.getText().trim());
        f.setVille(txtVille.getText().trim());
        return f;
    }

    private void modeAjout() {
        selection = null;
        txtNom.clear(); txtTelephone.clear(); txtEmail.clear(); txtAdresse.clear(); txtVille.clear();
        tableFournisseurs.getSelectionModel().clearSelection();
        btnAjouter.setDisable(false); btnModifier.setDisable(true); btnSupprimer.setDisable(true);
    }

    private void alerte(String msg) { new Alert(Alert.AlertType.WARNING, msg, ButtonType.OK).showAndWait(); }
    private void succes(String msg) { new Alert(Alert.AlertType.INFORMATION, msg, ButtonType.OK).showAndWait(); }
}
