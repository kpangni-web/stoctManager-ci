package com.inphb.icgl.stocks.dao;

import com.inphb.icgl.stocks.model.Fournisseur;
import com.inphb.icgl.stocks.repository.IFournisseurRepository;
import com.inphb.icgl.stocks.utils.DatabaseConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;

public class FournisseurDAO implements IFournisseurRepository {

    @Override
    public boolean save(Fournisseur f) {
        String sql = "INSERT INTO fournisseurs (nom, telephone, email, adresse, ville) VALUES (?,?,?,?,?)";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, f.getNom());
            ps.setString(2, f.getTelephone());
            ps.setString(3, f.getEmail());
            ps.setString(4, f.getAdresse());
            ps.setString(5, f.getVille());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[FournisseurDAO.save] " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean update(Fournisseur f) {
        String sql = "UPDATE fournisseurs SET nom=?, telephone=?, email=?, adresse=?, ville=? WHERE id=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, f.getNom());
            ps.setString(2, f.getTelephone());
            ps.setString(3, f.getEmail());
            ps.setString(4, f.getAdresse());
            ps.setString(5, f.getVille());
            ps.setInt(6, f.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[FournisseurDAO.update] " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        String sql = "DELETE FROM fournisseurs WHERE id=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[FournisseurDAO.delete] " + e.getMessage());
            return false;
        }
    }

    @Override
    public Fournisseur findById(int id) {
        String sql = "SELECT * FROM fournisseurs WHERE id=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
        } catch (SQLException e) {
            System.err.println("[FournisseurDAO.findById] " + e.getMessage());
        }
        return null;
    }

    @Override
    public ObservableList<Fournisseur> findAll(int page, int pageSize) {
        ObservableList<Fournisseur> list = FXCollections.observableArrayList();
        String sql = "SELECT * FROM fournisseurs ORDER BY nom LIMIT ? OFFSET ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, pageSize);
            ps.setInt(2, (page - 1) * pageSize);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            System.err.println("[FournisseurDAO.findAll] " + e.getMessage());
        }
        return list;
    }

    @Override
    public ObservableList<Fournisseur> findAll() {
        ObservableList<Fournisseur> list = FXCollections.observableArrayList();
        String sql = "SELECT * FROM fournisseurs ORDER BY nom";
        try (Statement st = DatabaseConnection.getConnection().createStatement()) {
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            System.err.println("[FournisseurDAO.findAll()] " + e.getMessage());
        }
        return list;
    }

    @Override
    public int countAll() {
        String sql = "SELECT COUNT(*) FROM fournisseurs";
        try (Statement st = DatabaseConnection.getConnection().createStatement()) {
            ResultSet rs = st.executeQuery(sql);
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("[FournisseurDAO.countAll] " + e.getMessage());
        }
        return 0;
    }

    @Override
    public ObservableList<Fournisseur> search(String motCle, int page, int pageSize) {
        ObservableList<Fournisseur> list = FXCollections.observableArrayList();
        String sql = "SELECT * FROM fournisseurs WHERE nom LIKE ? OR telephone LIKE ? ORDER BY nom LIMIT ? OFFSET ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            String like = "%" + motCle + "%";
            ps.setString(1, like);
            ps.setString(2, like);
            ps.setInt(3, pageSize);
            ps.setInt(4, (page - 1) * pageSize);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(map(rs));
        } catch (SQLException e) {
            System.err.println("[FournisseurDAO.search] " + e.getMessage());
        }
        return list;
    }

    @Override
    public int countSearch(String motCle) {
        String sql = "SELECT COUNT(*) FROM fournisseurs WHERE nom LIKE ? OR telephone LIKE ?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            String like = "%" + motCle + "%";
            ps.setString(1, like);
            ps.setString(2, like);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("[FournisseurDAO.countSearch] " + e.getMessage());
        }
        return 0;
    }

    @Override
    public boolean hasProducts(int idFournisseur) {
        String sql = "SELECT COUNT(*) FROM produits WHERE id_fournisseur=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, idFournisseur);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1) > 0;
        } catch (SQLException e) {
            System.err.println("[FournisseurDAO.hasProducts] " + e.getMessage());
        }
        return false;
    }

    private Fournisseur map(ResultSet rs) throws SQLException {
        return new Fournisseur(
            rs.getInt("id"),
            rs.getString("nom"),
            rs.getString("telephone"),
            rs.getString("email"),
            rs.getString("adresse"),
            rs.getString("ville")
        );
    }
}
