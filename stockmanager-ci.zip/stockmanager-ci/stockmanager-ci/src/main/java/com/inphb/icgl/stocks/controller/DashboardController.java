package com.inphb.icgl.stocks.controller;

import com.inphb.icgl.stocks.dao.MouvementDAO;
import com.inphb.icgl.stocks.dao.ProduitDAO;
import com.inphb.icgl.stocks.model.Produit;
import com.inphb.icgl.stocks.utils.SessionManager;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.text.NumberFormat;
import java.util.Locale;

public class DashboardController {

    @FXML private Label lblBienvenue;
    @FXML private Label lblTotalProduits;
    @FXML private Label lblProdEnAlerte;
    @FXML private Label lblMouvJour;
    @FXML private Label lblValeurStock;

    @FXML private TableView<Produit> tableAlerte;
    @FXML private TableColumn<Produit, String> colRef;
    @FXML private TableColumn<Produit, String> colDesig;
    @FXML private TableColumn<Produit, Integer> colQte;
    @FXML private TableColumn<Produit, Integer> colMin;
    @FXML private TableColumn<Produit, String> colUnite;

    private final ProduitDAO produitDAO     = new ProduitDAO();
    private final MouvementDAO mouvDAO      = new MouvementDAO();
    private final NumberFormat nf           = NumberFormat.getNumberInstance(Locale.FRANCE);

    @FXML
    public void initialize() {
        configurerTable();
        chargerIndicateurs();
    }

    private void configurerTable() {
        colRef.setCellValueFactory(new PropertyValueFactory<>("reference"));
        colDesig.setCellValueFactory(new PropertyValueFactory<>("designation"));
        colQte.setCellValueFactory(new PropertyValueFactory<>("quantiteStock"));
        colMin.setCellValueFactory(new PropertyValueFactory<>("stockMinimum"));
        colUnite.setCellValueFactory(new PropertyValueFactory<>("unite"));

        // Colorer en rouge les lignes en alerte
        tableAlerte.setRowFactory(tv -> new javafx.scene.control.TableRow<Produit>() {
            @Override
            protected void updateItem(Produit p, boolean empty) {
                super.updateItem(p, empty);
                if (p == null || empty) setStyle("");
                else if (p.isEnAlerte()) setStyle("-fx-background-color: #FFE0E0;");
                else setStyle("");
            }
        });
    }

    public void chargerIndicateurs() {
        // Bienvenue
        if (SessionManager.getUtilisateur() != null) {
            lblBienvenue.setText("Bienvenue, " + SessionManager.getUtilisateur().getNomComplet());
        }

        // Indicateurs chiffrés
        int totalProduits  = produitDAO.countAll();
        int prodEnAlerte   = produitDAO.countEnAlerte();
        int mouvJour       = mouvDAO.countMouvementsDuJour();
        double valeurStock = produitDAO.valeurTotaleStock();

        lblTotalProduits.setText(String.valueOf(totalProduits));
        lblMouvJour.setText(String.valueOf(mouvJour));

        lblProdEnAlerte.setText(String.valueOf(prodEnAlerte));
        if (prodEnAlerte > 0) {
            lblProdEnAlerte.setStyle("-fx-text-fill: #c0392b; -fx-font-weight: bold;");
        }

        lblValeurStock.setText(nf.format((long) valeurStock) + " FCFA");

        // Les 5 produits les plus critiques
        ObservableList<Produit> alertes = produitDAO.findEnAlerte();
        tableAlerte.setItems(alertes);
    }
}
