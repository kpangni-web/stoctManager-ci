package com.inphb.icgl.stocks.controller;

import com.inphb.icgl.stocks.dao.UtilisateurDAO;
import com.inphb.icgl.stocks.model.Utilisateur;
import com.inphb.icgl.stocks.utils.PasswordUtil;
import com.inphb.icgl.stocks.utils.SessionManager;
import javafx.animation.PauseTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.Duration;

public class LoginController {

    @FXML private TextField txtLogin;
    @FXML private PasswordField txtMotDePasse;
    @FXML private Button btnConnexion;
    @FXML private Button btnQuitter;
    @FXML private Label lblErreur;

    private final UtilisateurDAO dao = new UtilisateurDAO();
    private int tentatives = 0;
    private static final int MAX_TENTATIVES = 3;
    private static final int BLOCAGE_SECONDES = 30;

    @FXML
    public void initialize() {
        lblErreur.setText("");
        // Connexion au clic sur Entrée depuis le champ mot de passe
        txtMotDePasse.setOnAction(e -> handleConnexion());
    }

    @FXML
    private void handleConnexion() {
        String login = txtLogin.getText().trim();
        String mdp   = txtMotDePasse.getText();

        if (login.isEmpty() || mdp.isEmpty()) {
            afficherErreur("Veuillez remplir tous les champs.");
            return;
        }

        String hash = PasswordUtil.sha256(mdp);
        Utilisateur u = dao.authenticate(login, hash);

        if (u != null) {
            SessionManager.setUtilisateur(u);
            ouvrirApplication();
        } else {
            tentatives++;
            if (tentatives >= MAX_TENTATIVES) {
                bloquerInterface();
            } else {
                afficherErreur("Identifiants incorrects. Tentative " + tentatives + "/" + MAX_TENTATIVES);
            }
        }
    }

    @FXML
    private void handleQuitter() {
        System.exit(0);
    }

    private void afficherErreur(String message) {
        lblErreur.setStyle("-fx-text-fill: #c0392b;");
        lblErreur.setText(message);
        txtMotDePasse.clear();
    }

    private void bloquerInterface() {
        btnConnexion.setDisable(true);
        txtLogin.setDisable(true);
        txtMotDePasse.setDisable(true);
        afficherErreur("Compte bloqué. Réessayez dans " + BLOCAGE_SECONDES + " secondes.");

        PauseTransition pause = new PauseTransition(Duration.seconds(BLOCAGE_SECONDES));
        pause.setOnFinished(e -> {
            btnConnexion.setDisable(false);
            txtLogin.setDisable(false);
            txtMotDePasse.setDisable(false);
            tentatives = 0;
            lblErreur.setText("");
        });
        pause.play();
    }

    private void ouvrirApplication() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/MainLayout.fxml"));
            Stage mainStage = new Stage();
            mainStage.setTitle("StockManager CI — " +
                SessionManager.getUtilisateur().getNomComplet() + " [" +
                SessionManager.getUtilisateur().getRole() + "]");
            mainStage.setScene(new Scene(loader.load(), 1200, 720));
            mainStage.setMinWidth(900);
            mainStage.setMinHeight(600);
            mainStage.show();

            // Fermer la fenêtre de login
            Stage loginStage = (Stage) btnConnexion.getScene().getWindow();
            loginStage.close();
        } catch (Exception e) {
            afficherErreur("Erreur au chargement de l'application : " + e.getMessage());
            e.printStackTrace();
        }
    }
}
