package com.inphb.icgl.stocks.controller;

import com.inphb.icgl.stocks.dao.CategorieDAO;
import com.inphb.icgl.stocks.dao.FournisseurDAO;
import com.inphb.icgl.stocks.dao.ProduitDAO;
import com.inphb.icgl.stocks.model.Categorie;
import com.inphb.icgl.stocks.model.Fournisseur;
import com.inphb.icgl.stocks.model.Produit;
import com.inphb.icgl.stocks.utils.ExportUtil;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class ProduitController {

    // ── TableView ─────────────────────────────────────────────────────────────
    @FXML private TableView<Produit>            tableProduits;
    @FXML private TableColumn<Produit, String>  colRef;
    @FXML private TableColumn<Produit, String>  colDesig;
    @FXML private TableColumn<Produit, String>  colCategorie;
    @FXML private TableColumn<Produit, String>  colFournisseur;
    @FXML private TableColumn<Produit, Double>  colPrix;
    @FXML private TableColumn<Produit, Integer> colQte;
    @FXML private TableColumn<Produit, Integer> colMin;
    @FXML private TableColumn<Produit, String>  colUnite;

    // ── Formulaire ────────────────────────────────────────────────────────────
    @FXML private TextField      txtReference;
    @FXML private TextField      txtDesignation;
    @FXML private ComboBox<Categorie>   cbCategorie;
    @FXML private ComboBox<Fournisseur> cbFournisseur;
    @FXML private TextField      txtPrix;
    @FXML private TextField      txtQte;
    @FXML private TextField      txtMin;
    @FXML private ComboBox<String>   cbUnite;
    @FXML private Button         btnAjouter;
    @FXML private Button         btnModifier;
    @FXML private Button         btnSupprimer;
    @FXML private Button         btnAnnuler;
    @FXML private Button         btnExporter;

    // ── Recherche & pagination ────────────────────────────────────────────────
    @FXML private TextField txtRecherche;
    @FXML private Label     lblPagination;
    @FXML private Label     lblStatut;
    @FXML private Button    btnPrecedent;
    @FXML private Button    btnSuivant;

    private final ProduitDAO    dao      = new ProduitDAO();
    private final CategorieDAO  catDAO   = new CategorieDAO();
    private final FournisseurDAO fourDAO  = new FournisseurDAO();

    private static final int PAGE_SIZE = 15;
    private int pageCourante  = 1;
    private int totalPages    = 1;
    private String motCle     = "";
    private Produit selection  = null;

    @FXML
    public void initialize() {
        configurerTable();
        chargerComboBoxes();
        configurerRecherche();
        chargerPage();
        modeAjout();
    }

    private void configurerTable() {
        colRef.setCellValueFactory(new PropertyValueFactory<>("reference"));
        colDesig.setCellValueFactory(new PropertyValueFactory<>("designation"));
        colCategorie.setCellValueFactory(new PropertyValueFactory<>("nomCategorie"));
        colFournisseur.setCellValueFactory(new PropertyValueFactory<>("nomFournisseur"));
        colPrix.setCellValueFactory(new PropertyValueFactory<>("prixUnitaire"));
        colQte.setCellValueFactory(new PropertyValueFactory<>("quantiteStock"));
        colMin.setCellValueFactory(new PropertyValueFactory<>("stockMinimum"));
        colUnite.setCellValueFactory(new PropertyValueFactory<>("unite"));

        // ★ Alerte visuelle : ligne rouge si stock ≤ stock_minimum ★
        tableProduits.setRowFactory(tv -> new TableRow<Produit>() {
            @Override
            protected void updateItem(Produit p, boolean empty) {
                super.updateItem(p, empty);
                if (p == null || empty) setStyle("");
                else if (p.isEnAlerte()) setStyle("-fx-background-color: #FFE0E0;");
                else setStyle("");
            }
        });

        tableProduits.getSelectionModel().selectedItemProperty()
            .addListener((obs, old, nouveau) -> {
                if (nouveau != null) {
                    selection = nouveau;
                    remplirFormulaire(nouveau);
                    btnModifier.setDisable(false);
                    btnSupprimer.setDisable(false);
                    btnAjouter.setDisable(true);
                }
            });
    }

    private void chargerComboBoxes() {
        cbCategorie.setItems(catDAO.findAll());
        cbFournisseur.setItems(fourDAO.findAll());
        cbUnite.getItems().addAll("pièce", "kg", "litre", "sac", "carton", "boîte", "bidon", "rouleau", "m²");
        cbUnite.setValue("pièce");
    }

    private void configurerRecherche() {
        txtRecherche.textProperty().addListener((obs, old, val) -> {
            motCle = val.trim();
            pageCourante = 1;
            chargerPage();
        });
    }

    private void chargerPage() {
        int total;
        ObservableList<Produit> data;

        if (motCle.isEmpty()) {
            total = dao.countAll();
            data  = dao.findAll(pageCourante, PAGE_SIZE);
        } else {
            total = dao.countSearch(motCle);
            data  = dao.search(motCle, pageCourante, PAGE_SIZE);
        }

        totalPages = Math.max(1, (int) Math.ceil((double) total / PAGE_SIZE));
        tableProduits.setItems(data);
        lblPagination.setText("Page " + pageCourante + " / " + totalPages + " — " + total + " produit(s)");
        btnPrecedent.setDisable(pageCourante <= 1);
        btnSuivant.setDisable(pageCourante >= totalPages);
    }

    @FXML private void handlePrecedent() { pageCourante--; chargerPage(); }
    @FXML private void handleSuivant()   { pageCourante++; chargerPage(); }

    @FXML
    private void handleAjouter() {
        Produit p = lireFormulaire(new Produit());
        if (p == null) return;
        if (dao.save(p)) { succes("Produit ajouté."); rafraichir(); }
        else alerte("Erreur", "Ajout échoué (référence déjà existante ?).");
    }

    @FXML
    private void handleModifier() {
        if (selection == null) return;
        Produit p = lireFormulaire(selection);
        if (p == null) return;
        if (dao.update(p)) { succes("Produit modifié."); rafraichir(); }
        else alerte("Erreur", "Modification échouée.");
    }

    @FXML
    private void handleSupprimer() {
        if (selection == null) return;
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
            "Supprimer le produit « " + selection.getDesignation() + " » ?\n" +
            "(Les mouvements associés seront supprimés)", ButtonType.YES, ButtonType.NO);
        confirm.setTitle("Confirmation");
        confirm.showAndWait().ifPresent(btn -> {
            if (btn == ButtonType.YES) {
                if (dao.delete(selection.getId())) { succes("Produit supprimé."); rafraichir(); }
                else alerte("Erreur", "Suppression échouée.");
            }
        });
    }

    @FXML
    private void handleAnnuler() { modeAjout(); }

    @FXML
    private void handleExporter() {
        FileChooser fc = new FileChooser();
        fc.setTitle("Enregistrer le fichier Excel");
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Fichier Excel", "*.xlsx"));
        fc.setInitialFileName("produits_stock.xlsx");
        File fichier = fc.showSaveDialog(tableProduits.getScene().getWindow());
        if (fichier != null) {
            try {
                // Exporter TOUS les produits (pas seulement la page courante)
                List<Produit> tous = dao.findAll(1, Integer.MAX_VALUE);
                ExportUtil.exporterProduits(tous, fichier);
                lblStatut.setText("Export réussi : " + fichier.getAbsolutePath());
            } catch (IOException e) {
                alerte("Erreur d'export", "Impossible d'écrire le fichier : " + e.getMessage());
            }
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private Produit lireFormulaire(Produit p) {
        String ref   = txtReference.getText().trim();
        String desig = txtDesignation.getText().trim();
        if (ref.isEmpty() || desig.isEmpty()) {
            alerte("Champs manquants", "La référence et la désignation sont obligatoires.");
            return null;
        }
        double prix; int qte; int min;
        try {
            prix = Double.parseDouble(txtPrix.getText().trim().replace(",", "."));
            qte  = Integer.parseInt(txtQte.getText().trim());
            min  = Integer.parseInt(txtMin.getText().trim());
        } catch (NumberFormatException e) {
            alerte("Saisie invalide", "Prix, quantité et stock minimum doivent être numériques.");
            return null;
        }

        p.setReference(ref);
        p.setDesignation(desig);
        Categorie cat = cbCategorie.getValue();
        Fournisseur four = cbFournisseur.getValue();
        p.setIdCategorie(cat != null ? cat.getId() : 0);
        p.setIdFournisseur(four != null ? four.getId() : 0);
        p.setPrixUnitaire(prix);
        p.setQuantiteStock(qte);
        p.setStockMinimum(min);
        p.setUnite(cbUnite.getValue() != null ? cbUnite.getValue() : "pièce");
        return p;
    }

    private void remplirFormulaire(Produit p) {
        txtReference.setText(p.getReference());
        txtDesignation.setText(p.getDesignation());
        txtPrix.setText(String.valueOf(p.getPrixUnitaire()));
        txtQte.setText(String.valueOf(p.getQuantiteStock()));
        txtMin.setText(String.valueOf(p.getStockMinimum()));
        cbUnite.setValue(p.getUnite());
        // Sélectionner la catégorie dans la ComboBox
        cbCategorie.getItems().stream()
            .filter(c -> c.getId() == p.getIdCategorie()).findFirst()
            .ifPresent(cbCategorie::setValue);
        cbFournisseur.getItems().stream()
            .filter(f -> f.getId() == p.getIdFournisseur()).findFirst()
            .ifPresent(cbFournisseur::setValue);
    }

    private void modeAjout() {
        selection = null;
        txtReference.clear(); txtDesignation.clear();
        txtPrix.setText("0"); txtQte.setText("0"); txtMin.setText("5");
        cbCategorie.setValue(null); cbFournisseur.setValue(null); cbUnite.setValue("pièce");
        tableProduits.getSelectionModel().clearSelection();
        btnAjouter.setDisable(false);
        btnModifier.setDisable(true);
        btnSupprimer.setDisable(true);
        lblStatut.setText("");
    }

    private void rafraichir() { modeAjout(); chargerPage(); }

    private void alerte(String titre, String msg) {
        new Alert(Alert.AlertType.WARNING, msg, ButtonType.OK).showAndWait();
    }

    private void succes(String msg) {
        new Alert(Alert.AlertType.INFORMATION, msg, ButtonType.OK).showAndWait();
    }
}
