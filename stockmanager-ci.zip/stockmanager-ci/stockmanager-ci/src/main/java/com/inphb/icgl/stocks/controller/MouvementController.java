package com.inphb.icgl.stocks.controller;

import com.inphb.icgl.stocks.dao.MouvementDAO;
import com.inphb.icgl.stocks.dao.ProduitDAO;
import com.inphb.icgl.stocks.model.Mouvement;
import com.inphb.icgl.stocks.model.Produit;
import com.inphb.icgl.stocks.utils.SessionManager;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class MouvementController {

    // ── TableView ─────────────────────────────────────────────────────────────
    @FXML private TableView<Mouvement>           tableMouvements;
    @FXML private TableColumn<Mouvement, String> colProduit;
    @FXML private TableColumn<Mouvement, String> colType;
    @FXML private TableColumn<Mouvement, Integer>colQte;
    @FXML private TableColumn<Mouvement, String> colMotif;
    @FXML private TableColumn<Mouvement, String> colUtilisateur;
    @FXML private TableColumn<Mouvement, String> colDate;

    // ── Formulaire ────────────────────────────────────────────────────────────
    @FXML private ComboBox<Produit>  cbProduit;
    @FXML private ToggleGroup        toggleType;
    @FXML private RadioButton        rbEntree;
    @FXML private RadioButton        rbSortie;
    @FXML private TextField          txtQuantite;
    @FXML private TextField          txtMotif;
    @FXML private Button             btnValider;
    @FXML private Label              lblStockDispo;

    // ── Pagination ────────────────────────────────────────────────────────────
    @FXML private Label  lblPagination;
    @FXML private Button btnPrecedent;
    @FXML private Button btnSuivant;

    private final MouvementDAO dao      = new MouvementDAO();
    private final ProduitDAO   prodDAO  = new ProduitDAO();
    private static final int   PAGE_SIZE = 15;
    private int pageCourante = 1;
    private int totalPages   = 1;

    @FXML
    public void initialize() {
        configurerTable();
        chargerProduits();
        chargerPage();

        // Afficher le stock disponible quand on sélectionne un produit
        cbProduit.getSelectionModel().selectedItemProperty().addListener((obs, old, p) -> {
            if (p != null) {
                lblStockDispo.setText("Stock actuel : " + p.getQuantiteStock() + " " + p.getUnite());
            }
        });
    }

    private void configurerTable() {
        colProduit.setCellValueFactory(new PropertyValueFactory<>("nomProduit"));
        colType.setCellValueFactory(new PropertyValueFactory<>("typeMouvement"));
        colQte.setCellValueFactory(new PropertyValueFactory<>("quantite"));
        colMotif.setCellValueFactory(new PropertyValueFactory<>("motif"));
        colUtilisateur.setCellValueFactory(new PropertyValueFactory<>("nomUtilisateur"));
        // Colonne date formatée (valeur calculée)
        colDate.setCellValueFactory(cd -> new javafx.beans.property.SimpleStringProperty(
            cd.getValue().getDateFormatee()));

        // Colorer les ENTREES en vert clair, les SORTIES en rouge clair
        tableMouvements.setRowFactory(tv -> new TableRow<Mouvement>() {
            @Override
            protected void updateItem(Mouvement m, boolean empty) {
                super.updateItem(m, empty);
                if (m == null || empty) setStyle("");
                else if ("ENTREE".equals(m.getTypeMouvement())) setStyle("-fx-background-color: #E8F8E8;");
                else setStyle("-fx-background-color: #FFE0E0;");
            }
        });
    }

    private void chargerProduits() {
        // Charger tous les produits pour la ComboBox (sans pagination)
        ObservableList<Produit> produits = prodDAO.findAll(1, Integer.MAX_VALUE);
        cbProduit.setItems(produits);
    }

    private void chargerPage() {
        int total = dao.countAll();
        ObservableList<Mouvement> data = dao.findAll(pageCourante, PAGE_SIZE);

        totalPages = Math.max(1, (int) Math.ceil((double) total / PAGE_SIZE));
        tableMouvements.setItems(data);
        lblPagination.setText("Page " + pageCourante + " / " + totalPages + " — " + total + " mouvement(s)");
        btnPrecedent.setDisable(pageCourante <= 1);
        btnSuivant.setDisable(pageCourante >= totalPages);
    }

    @FXML private void handlePrecedent() { pageCourante--; chargerPage(); }
    @FXML private void handleSuivant()   { pageCourante++; chargerPage(); }

    @FXML
    private void handleValider() {
        Produit produit = cbProduit.getValue();
        if (produit == null) { alerte("Erreur", "Sélectionnez un produit."); return; }

        String type = rbEntree.isSelected() ? "ENTREE" : "SORTIE";
        int qte;
        try {
            qte = Integer.parseInt(txtQuantite.getText().trim());
            if (qte <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            alerte("Erreur", "La quantité doit être un entier positif.");
            return;
        }

        String motif = txtMotif.getText().trim();

        Mouvement m = new Mouvement();
        m.setIdProduit(produit.getId());
        m.setTypeMouvement(type);
        m.setQuantite(qte);
        m.setMotif(motif);
        if (SessionManager.getUtilisateur() != null) {
            m.setIdUtilisateur(SessionManager.getUtilisateur().getId());
        }

        if (dao.save(m)) {
            // Rafraîchir le stock dans la ComboBox
            chargerProduits();
            // Resélectionner le même produit pour mettre à jour lblStockDispo
            Produit maj = prodDAO.findById(produit.getId());
            cbProduit.setValue(maj);
            txtQuantite.clear();
            txtMotif.clear();
            chargerPage();
            succes(type + " de " + qte + " " + produit.getUnite() + " enregistrée.");
        } else {
            alerte("Erreur", "Opération échouée.\nStock insuffisant pour une sortie ?");
        }
    }

    private void alerte(String titre, String msg) {
        new Alert(Alert.AlertType.WARNING, msg, ButtonType.OK).showAndWait();
    }
    private void succes(String msg) {
        new Alert(Alert.AlertType.INFORMATION, msg, ButtonType.OK).showAndWait();
    }
}
