package com.inphb.icgl.stocks.controller;

import com.inphb.icgl.stocks.dao.UtilisateurDAO;
import com.inphb.icgl.stocks.model.Utilisateur;
import com.inphb.icgl.stocks.utils.SessionManager;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class UtilisateurController {

    @FXML private TableView<Utilisateur>            tableUtilisateurs;
    @FXML private TableColumn<Utilisateur, Integer> colId;
    @FXML private TableColumn<Utilisateur, String>  colNom;
    @FXML private TableColumn<Utilisateur, String>  colLogin;
    @FXML private TableColumn<Utilisateur, String>  colRole;
    @FXML private TableColumn<Utilisateur, Boolean> colActif;

    @FXML private TextField    txtNomComplet;
    @FXML private TextField    txtLogin;
    @FXML private PasswordField txtMotDePasse;
    @FXML private ComboBox<String> cbRole;
    @FXML private Button       btnAjouter;
    @FXML private Button       btnModifier;
    @FXML private Button       btnDesactiver;
    @FXML private Button       btnAnnuler;
    @FXML private Label        lblPagination;
    @FXML private Button       btnPrecedent;
    @FXML private Button       btnSuivant;

    private final UtilisateurDAO dao = new UtilisateurDAO();
    private static final int PAGE_SIZE = 15;
    private int pageCourante = 1, totalPages = 1;
    private Utilisateur selection = null;

    @FXML
    public void initialize() {
        // Seuls les ADMIN peuvent accéder à ce module (vérification défensive)
        if (!SessionManager.isAdmin()) {
            alerte("Accès refusé", "Ce module est réservé aux administrateurs.");
            return;
        }

        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNom.setCellValueFactory(new PropertyValueFactory<>("nomComplet"));
        colLogin.setCellValueFactory(new PropertyValueFactory<>("login"));
        colRole.setCellValueFactory(new PropertyValueFactory<>("role"));
        colActif.setCellValueFactory(new PropertyValueFactory<>("actif"));

        cbRole.getItems().addAll("ADMIN", "GESTIONNAIRE");
        cbRole.setValue("GESTIONNAIRE");

        tableUtilisateurs.getSelectionModel().selectedItemProperty()
            .addListener((obs, old, u) -> {
                if (u != null) {
                    selection = u;
                    txtNomComplet.setText(u.getNomComplet());
                    txtLogin.setText(u.getLogin());
                    txtMotDePasse.clear(); // Ne jamais pré-remplir le mot de passe
                    cbRole.setValue(u.getRole());
                    btnModifier.setDisable(false);
                    // Un admin ne peut pas se désactiver lui-même
                    boolean estSoi = u.getId() == SessionManager.getUtilisateur().getId();
                    btnDesactiver.setDisable(estSoi || !u.isActif());
                    btnAjouter.setDisable(true);
                }
            });

        chargerPage(); modeAjout();
    }

    private void chargerPage() {
        int total = dao.countAll();
        ObservableList<Utilisateur> data = dao.findAll(pageCourante, PAGE_SIZE);
        totalPages = Math.max(1, (int) Math.ceil((double) total / PAGE_SIZE));
        tableUtilisateurs.setItems(data);
        lblPagination.setText("Page " + pageCourante + " / " + totalPages + " — " + total + " utilisateur(s)");
        btnPrecedent.setDisable(pageCourante <= 1);
        btnSuivant.setDisable(pageCourante >= totalPages);
    }

    @FXML private void handlePrecedent() { pageCourante--; chargerPage(); }
    @FXML private void handleSuivant()   { pageCourante++; chargerPage(); }

    @FXML
    private void handleAjouter() {
        if (txtNomComplet.getText().trim().isEmpty() || txtLogin.getText().trim().isEmpty()) {
            alerte("Champs manquants", "Nom complet et login sont obligatoires."); return;
        }
        if (txtMotDePasse.getText().isEmpty()) {
            alerte("Mot de passe requis", "Saisissez un mot de passe pour le nouvel utilisateur."); return;
        }
        Utilisateur u = new Utilisateur(0, txtNomComplet.getText().trim(),
            txtLogin.getText().trim(), cbRole.getValue(), true);
        u.setMotDePasse(txtMotDePasse.getText()); // sera hashé dans le DAO
        if (dao.save(u)) { succes("Utilisateur créé."); modeAjout(); chargerPage(); }
        else alerte("Erreur", "Création échouée (login déjà existant ?).");
    }

    @FXML
    private void handleModifier() {
        if (selection == null) return;
        selection.setNomComplet(txtNomComplet.getText().trim());
        selection.setLogin(txtLogin.getText().trim());
        selection.setRole(cbRole.getValue());
        selection.setMotDePasse(txtMotDePasse.getText()); // vide = pas de changement (géré dans DAO)
        if (dao.update(selection)) { succes("Utilisateur modifié."); modeAjout(); chargerPage(); }
        else alerte("Erreur", "Modification échouée.");
    }

    @FXML
    private void handleDesactiver() {
        if (selection == null) return;
        Alert c = new Alert(Alert.AlertType.CONFIRMATION,
            "Désactiver le compte de " + selection.getNomComplet() + " ?",
            ButtonType.YES, ButtonType.NO);
        c.showAndWait().ifPresent(b -> {
            if (b == ButtonType.YES && dao.desactiver(selection.getId())) {
                succes("Compte désactivé."); modeAjout(); chargerPage();
            }
        });
    }

    @FXML private void handleAnnuler() { modeAjout(); }

    private void modeAjout() {
        selection = null;
        txtNomComplet.clear(); txtLogin.clear(); txtMotDePasse.clear();
        cbRole.setValue("GESTIONNAIRE");
        tableUtilisateurs.getSelectionModel().clearSelection();
        btnAjouter.setDisable(false); btnModifier.setDisable(true); btnDesactiver.setDisable(true);
    }

    private void alerte(String titre, String msg) {
        new Alert(Alert.AlertType.WARNING, msg, ButtonType.OK).showAndWait();
    }
    private void succes(String msg) {
        new Alert(Alert.AlertType.INFORMATION, msg, ButtonType.OK).showAndWait();
    }
}
