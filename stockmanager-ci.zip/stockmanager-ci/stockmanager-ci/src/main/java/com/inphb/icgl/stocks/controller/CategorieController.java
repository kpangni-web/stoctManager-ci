package com.inphb.icgl.stocks.controller;

import com.inphb.icgl.stocks.dao.CategorieDAO;
import com.inphb.icgl.stocks.model.Categorie;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

public class CategorieController {

    // ── TableView ─────────────────────────────────────────────────────────────
    @FXML private TableView<Categorie>          tableCategories;
    @FXML private TableColumn<Categorie, Integer> colId;
    @FXML private TableColumn<Categorie, String>  colLibelle;
    @FXML private TableColumn<Categorie, String>  colDescription;

    // ── Formulaire ────────────────────────────────────────────────────────────
    @FXML private TextField   txtLibelle;
    @FXML private TextField   txtDescription;
    @FXML private Button      btnAjouter;
    @FXML private Button      btnModifier;
    @FXML private Button      btnSupprimer;
    @FXML private Button      btnAnnuler;

    // ── Recherche ─────────────────────────────────────────────────────────────
    @FXML private TextField   txtRecherche;

    // ── Pagination ────────────────────────────────────────────────────────────
    @FXML private Label       lblPagination;
    @FXML private Button      btnPrecedent;
    @FXML private Button      btnSuivant;

    private final CategorieDAO dao = new CategorieDAO();
    private static final int PAGE_SIZE = 15;
    private int pageCourante = 1;
    private int totalPages   = 1;
    private String motCleActuel = "";
    private Categorie selectionActuelle = null;

    @FXML
    public void initialize() {
        configurerTable();
        configurerRecherche();
        chargerPage();
        modeAjout();
    }

    private void configurerTable() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colLibelle.setCellValueFactory(new PropertyValueFactory<>("libelle"));
        colDescription.setCellValueFactory(new PropertyValueFactory<>("description"));

        // Sélection dans le tableau → pré-remplir le formulaire
        tableCategories.getSelectionModel().selectedItemProperty().addListener((obs, old, nouvelle) -> {
            if (nouvelle != null) {
                selectionActuelle = nouvelle;
                txtLibelle.setText(nouvelle.getLibelle());
                txtDescription.setText(nouvelle.getDescription());
                btnModifier.setDisable(false);
                btnSupprimer.setDisable(false);
                btnAjouter.setDisable(true);
            }
        });
    }

    private void configurerRecherche() {
        txtRecherche.textProperty().addListener((obs, old, val) -> {
            motCleActuel = val.trim();
            pageCourante = 1;
            chargerPage();
        });
    }

    private void chargerPage() {
        int total;
        ObservableList<Categorie> data;

        if (motCleActuel.isEmpty()) {
            total = dao.countAll();
            data  = dao.findAll(pageCourante, PAGE_SIZE);
        } else {
            total = dao.countSearch(motCleActuel);
            data  = dao.search(motCleActuel, pageCourante, PAGE_SIZE);
        }

        totalPages = Math.max(1, (int) Math.ceil((double) total / PAGE_SIZE));
        tableCategories.setItems(data);
        lblPagination.setText("Page " + pageCourante + " / " + totalPages + " — " + total + " catégorie(s)");
        btnPrecedent.setDisable(pageCourante <= 1);
        btnSuivant.setDisable(pageCourante >= totalPages);
    }

    @FXML private void handlePrecedent() { pageCourante--; chargerPage(); }
    @FXML private void handleSuivant()   { pageCourante++; chargerPage(); }

    @FXML
    private void handleAjouter() {
        String lib = txtLibelle.getText().trim();
        if (lib.isEmpty()) { alerte("Erreur", "Le libellé est obligatoire."); return; }

        Categorie c = new Categorie(0, lib, txtDescription.getText().trim());
        if (dao.save(c)) {
            succes("Catégorie ajoutée avec succès.");
            rafraichir();
        } else {
            alerte("Erreur", "Impossible d'ajouter (libellé déjà existant ?).");
        }
    }

    @FXML
    private void handleModifier() {
        if (selectionActuelle == null) return;
        String lib = txtLibelle.getText().trim();
        if (lib.isEmpty()) { alerte("Erreur", "Le libellé est obligatoire."); return; }

        selectionActuelle.setLibelle(lib);
        selectionActuelle.setDescription(txtDescription.getText().trim());
        if (dao.update(selectionActuelle)) {
            succes("Catégorie modifiée avec succès.");
            rafraichir();
        } else {
            alerte("Erreur", "Échec de la modification.");
        }
    }

    @FXML
    private void handleSupprimer() {
        if (selectionActuelle == null) return;

        if (dao.hasProducts(selectionActuelle.getId())) {
            alerte("Suppression impossible",
                "Des produits sont rattachés à cette catégorie.\n" +
                "Réaffectez-les avant de supprimer la catégorie.");
            return;
        }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
            "Supprimer la catégorie « " + selectionActuelle.getLibelle() + " » ?",
            ButtonType.YES, ButtonType.NO);
        confirm.setTitle("Confirmation");
        confirm.showAndWait().ifPresent(btn -> {
            if (btn == ButtonType.YES) {
                if (dao.delete(selectionActuelle.getId())) {
                    succes("Catégorie supprimée.");
                    rafraichir();
                } else {
                    alerte("Erreur", "Échec de la suppression.");
                }
            }
        });
    }

    @FXML
    private void handleAnnuler() {
        modeAjout();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void modeAjout() {
        selectionActuelle = null;
        txtLibelle.clear();
        txtDescription.clear();
        tableCategories.getSelectionModel().clearSelection();
        btnAjouter.setDisable(false);
        btnModifier.setDisable(true);
        btnSupprimer.setDisable(true);
    }

    private void rafraichir() {
        modeAjout();
        chargerPage();
    }

    private void alerte(String titre, String message) {
        Alert a = new Alert(Alert.AlertType.WARNING, message, ButtonType.OK);
        a.setTitle(titre);
        a.setHeaderText(null);
        a.showAndWait();
    }

    private void succes(String message) {
        Alert a = new Alert(Alert.AlertType.INFORMATION, message, ButtonType.OK);
        a.setTitle("Succès");
        a.setHeaderText(null);
        a.showAndWait();
    }
}
