package com.inphb.icgl.stocks.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Utilitaire de hashage des mots de passe en SHA-256.
 * Les mots de passe ne sont JAMAIS stockés en clair dans la base.
 */
public class PasswordUtil {

    private PasswordUtil() {}

    /**
     * Retourne le hash SHA-256 hexadécimal d'un mot de passe.
     * Exemple : sha256("admin123") → "240be518..."
     */
    public static String sha256(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            // SHA-256 est toujours disponible en Java SE
            throw new RuntimeException("SHA-256 non disponible", e);
        }
    }

    /**
     * Vérifie si un mot de passe en clair correspond à un hash stocké.
     */
    public static boolean verify(String plainPassword, String storedHash) {
        return sha256(plainPassword).equalsIgnoreCase(storedHash);
    }
}
