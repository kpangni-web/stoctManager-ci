-- ══════════════════════════════════════════════════════════════
-- BASE DE DONNÉES : stockmanager_ci
-- Contexte : Commerce ivoirien / Afrique de l'Ouest
-- INP-HB IC-GL 2025-2026
-- ══════════════════════════════════════════════════════════════

CREATE DATABASE IF NOT EXISTS stockmanager_ci
    CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE stockmanager_ci;

-- ── TABLE 1 : utilisateurs ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS utilisateurs (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    nom_complet  VARCHAR(150) NOT NULL,
    login        VARCHAR(50)  NOT NULL UNIQUE,
    mot_de_passe VARCHAR(64)  NOT NULL,  -- hash SHA-256
    role         ENUM('ADMIN','GESTIONNAIRE') DEFAULT 'GESTIONNAIRE',
    actif        TINYINT(1) DEFAULT 1,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ── TABLE 2 : categories ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS categories (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    libelle     VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(255)
);

-- ── TABLE 3 : fournisseurs ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS fournisseurs (
    id        INT AUTO_INCREMENT PRIMARY KEY,
    nom       VARCHAR(150) NOT NULL,
    telephone VARCHAR(20),
    email     VARCHAR(100),
    adresse   VARCHAR(255),
    ville     VARCHAR(100)
);

-- ── TABLE 4 : produits ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS produits (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    reference       VARCHAR(30)    NOT NULL UNIQUE,
    designation     VARCHAR(200)   NOT NULL,
    id_categorie    INT,
    id_fournisseur  INT,
    prix_unitaire   DECIMAL(12,2)  NOT NULL DEFAULT 0.00,
    quantite_stock  INT            NOT NULL DEFAULT 0,
    stock_minimum   INT            NOT NULL DEFAULT 5,
    unite           VARCHAR(30)    DEFAULT 'pièce',
    created_at      TIMESTAMP      DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_categorie)   REFERENCES categories(id)   ON DELETE SET NULL,
    FOREIGN KEY (id_fournisseur) REFERENCES fournisseurs(id) ON DELETE SET NULL
);

-- ── TABLE 5 : mouvements ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS mouvements (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    id_produit      INT  NOT NULL,
    type_mouvement  ENUM('ENTREE','SORTIE') NOT NULL,
    quantite        INT  NOT NULL,
    motif           VARCHAR(255),
    id_utilisateur  INT,
    date_mouvement  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_produit)     REFERENCES produits(id)     ON DELETE CASCADE,
    FOREIGN KEY (id_utilisateur) REFERENCES utilisateurs(id) ON DELETE SET NULL
);

-- ══════════════════════════════════════════════════════════════
-- DONNÉES INITIALES (contexte ivoirien)
-- ══════════════════════════════════════════════════════════════

INSERT INTO utilisateurs (nom_complet, login, mot_de_passe, role) VALUES
    ('Administrateur Système', 'admin',  SHA2('admin123',256),   'ADMIN'),
    ('Kouamé Gestionnaire',   'kouame', SHA2('kouame2026',256), 'GESTIONNAIRE');

INSERT INTO categories (libelle, description) VALUES
    ('Alimentaire',  'Produits alimentaires et boissons'),
    ('Quincaillerie','Matériaux de construction et outils'),
    ('Papeterie',    'Fournitures scolaires et de bureau'),
    ('Électronique', 'Appareils et accessoires électroniques'),
    ('Médicament',   'Produits pharmaceutiques et hygiène');

INSERT INTO fournisseurs (nom, telephone, email, ville) VALUES
    ('SIFCA Distribution',    '27 20 25 00 00', 'contact@sifca.ci',    'Abidjan'),
    ('SIMAT Quincaillerie',   '27 20 31 12 00', 'simat@simat.ci',      'Abidjan'),
    ('CFAO Technologies',     '27 21 00 11 00', 'cfao@cfao.ci',        'Abidjan'),
    ('Librairie de France CI','27 20 22 50 00', 'ldf@librairie.ci',    'Abidjan'),
    ('COPHARMED',             '27 20 37 40 00', 'copharmed@cop.ci',    'Abidjan');

INSERT INTO produits (reference, designation, id_categorie, id_fournisseur, prix_unitaire, quantite_stock, stock_minimum, unite) VALUES
    ('CIM-CPI-425',  'Ciment CPI 42.5',           2, 2, 6500.00,  80,  20, 'Sac'),
    ('HUI-DIN-5L',   'Huile Palme Dinor 5L',       1, 1, 4200.00,   3,  10, 'Bidon'),
    ('STY-BIC-B50',  'Stylo Bic Cristal (boîte 50)',3, 4, 1500.00,  25,   5, 'Boîte'),
    ('MED-PAR-500',  'Paracétamol 500mg (boîte)',   5, 5,  850.00,   2,  15, 'Boîte'),
    ('TOL-OND-3M',   'Tôle ondulée 3m',             2, 2, 8500.00,  12,   5, 'Pièce'),
    ('RIZ-IMP-25K',  'Riz importé 25kg',            1, 1, 18000.00, 40,  10, 'Sac'),
    ('CIM-CPJ-325',  'Ciment CPJ 32.5',             2, 2, 5800.00,  60,  20, 'Sac'),
    ('SAV-PEY-200',  'Savon Peyo 200g',             1, 1,  350.00,   4,  30, 'Pièce');
